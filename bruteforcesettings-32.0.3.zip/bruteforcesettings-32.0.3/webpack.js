/* global require, module */
const webpackConfig = require('@nextcloud/webpack-vue-config')

module.exports = webpackConfig
