OC.L10N.register(
    "bruteforcesettings",
    {
    "Comment" : "Komentar",
    "Add" : "Masukkan",
    "Save" : "Simpan"
},
"nplurals=1; plural=0;");
