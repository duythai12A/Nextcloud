OC.L10N.register(
    "bruteforcesettings",
    {
    "Brute-force settings" : "Cunfiguratzione de fortza bruta",
    "Whitelist IPs" : "Lista bianca de is IP",
    "Comment" : "Cummentu",
    "Add" : "Agiunghe ",
    "Save" : "Sarva",
    "Brute-force IP whitelist" : "Lista bianca de IP de Fortza Bruta",
    "To whitelist IP ranges from the brute-force protection specify them below. Note that any whitelisted IP can perform authentication attempts without any throttling. For security reasons, it is recommended to whitelist as few hosts as possible or ideally even none at all." : "Pro fàghere sa lista de is grupos de IP esclùdidos dae s'amparu dae sa fortza bruta, ispetzìfica.ddus inoghe a suta. Càstia ca is IP in sa lista bianca podent fàghere tentativos de autenticatzione chentza lìmite perunu. Pro resones de seguresa, est cussigiadu pònnere in sa lista bianca prus pagus host possìbiles o, mègius, perunu etotu.",
    "Add a new whitelist" : "Agiunghe una lista bianca noa"
},
"nplurals=2; plural=(n != 1);");
