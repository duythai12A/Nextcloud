OC.L10N.register(
    "bruteforcesettings",
    {
    "Add" : "சேர்க்க",
    "Save" : "சேமிக்க "
},
"nplurals=2; plural=(n != 1);");
