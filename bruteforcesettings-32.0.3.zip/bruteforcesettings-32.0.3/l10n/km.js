OC.L10N.register(
    "bruteforcesettings",
    {
    "Comment" : "មតិ",
    "Add" : "បញ្ចូល",
    "Save" : "រក្សាទុក"
},
"nplurals=1; plural=0;");
