OC.L10N.register(
    "bruteforcesettings",
    {
    "Comment" : "Komentariya",
    "Add" : "Əlavə etmək",
    "Save" : "Saxla"
},
"nplurals=2; plural=(n != 1);");
