OC.L10N.register(
    "bruteforcesettings",
    {
    "Comment" : "تبصره",
    "Save" : "ساتل"
},
"nplurals=2; plural=(n != 1);");
