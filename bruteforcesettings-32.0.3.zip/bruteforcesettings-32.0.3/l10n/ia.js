OC.L10N.register(
    "bruteforcesettings",
    {
    "Comment" : "Commentario",
    "Add" : "Adder",
    "Save" : "Salveguardar"
},
"nplurals=2; plural=(n != 1);");
