OC.L10N.register(
    "bruteforcesettings",
    {
    "Brute-force settings" : "Väsytyshyökkäyksen asetukset",
    "Whitelist IPs" : "Sallitut IP:t",
    "Comment" : "Kommentti",
    "Add" : "Lisää",
    "Save" : "Tallenna",
    "Brute-force IP whitelist" : "Turvallisten IP-osoitteiden lista"
},
"nplurals=2; plural=(n != 1);");
