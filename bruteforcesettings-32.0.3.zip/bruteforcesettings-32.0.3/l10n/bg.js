OC.L10N.register(
    "bruteforcesettings",
    {
    "Brute-force settings" : "Настройки за атаки \"груба сила\"",
    "Whitelist IPs" : "Whitelist IPs/IP адреси в белия списък/",
    "Comment" : "Коментар",
    "Add" : "Добавяне",
    "Save" : "Запиши",
    "Brute-force IP whitelist" : "IP бял списък за атаки \"груба сила\"",
    "To whitelist IP ranges from the brute-force protection specify them below. Note that any whitelisted IP can perform authentication attempts without any throttling. For security reasons, it is recommended to whitelist as few hosts as possible or ideally even none at all." : "За да включите в белия списък IP диапазоните от brute-force protection, посочете ги по-долу. Имайте предвид, че всеки IP от белия списък може да извършва опити за удостоверяване без никакво ограничаване. От съображения за сигурност се препоръчва да поставите в белия списък възможно най-малко хостове или в идеалния случай нито един дори."
},
"nplurals=2; plural=(n != 1);");
