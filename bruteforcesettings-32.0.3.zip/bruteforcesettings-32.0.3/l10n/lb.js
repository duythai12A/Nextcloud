OC.L10N.register(
    "bruteforcesettings",
    {
    "Comment" : "Kommentar",
    "Add" : "Derbäimaachen",
    "Save" : "Späicheren"
},
"nplurals=2; plural=(n != 1);");
