OC.L10N.register(
    "bruteforcesettings",
    {
    "Brute-force settings" : "Configuraciones de fuerza-bruta",
    "Comment" : "Comentario",
    "Add" : "Agregar",
    "Save" : "Guardar",
    "Brute-force IP whitelist" : "IPs en lista blanca de fuerza-bruta"
},
"nplurals=3; plural=n == 1 ? 0 : n != 0 && n % 1000000 == 0 ? 1 : 2;");
