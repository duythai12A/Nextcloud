OC.L10N.register(
    "bruteforcesettings",
    {
    "Brute-force settings" : "Agordoj pri elĉerpa serĉo",
    "Whitelist IPs" : "Blanklistigi retadresojn",
    "Comment" : "Komento",
    "Add" : "Aldoni",
    "Save" : "Konservi",
    "Brute-force IP whitelist" : "Blanklistaj retadresoj pri protekto kontraŭ elĉerpa serĉo",
    "To whitelist IP ranges from the brute-force protection specify them below. Note that any whitelisted IP can perform authentication attempts without any throttling. For security reasons, it is recommended to whitelist as few hosts as possible or ideally even none at all." : "Por blanklistigi retadresan intervalon, entajpu ilin ĉi-sube. Notu, ke iu ajn retadreso en la blanka listo povas provi aŭtentiĝi sen iu prokrasto. Pro sekurigaj kialoj, oni rekomendas blanklistigi kiel eble plej malmulte de retadreso aŭ eĉ neniun."
},
"nplurals=2; plural=(n != 1);");
