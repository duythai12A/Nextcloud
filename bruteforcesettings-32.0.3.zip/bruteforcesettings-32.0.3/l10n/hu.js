OC.L10N.register(
    "bruteforcesettings",
    {
    "Brute-force settings" : "Brute-force beállítások",
    "Whitelist IPs" : "IP-címek fehérlistára tétele",
    "Comment" : "Megjegyzés",
    "Add" : "Hozzáadás",
    "Save" : "Mentés",
    "Delete entry for {subnet}" : "{subnet} bejegyzés törlése",
    "Brute-force IP whitelist" : "Brute-force IP-cím fehérlista",
    "To whitelist IP ranges from the brute-force protection specify them below. Note that any whitelisted IP can perform authentication attempts without any throttling. For security reasons, it is recommended to whitelist as few hosts as possible or ideally even none at all." : "Itt adhatja meg a brute-force támadás elleni védelem szempontjából fehérlistára tett IP-tartományokat. Vegye figyelembe, hogy minden ilyen IP-cím hitelesítési kérelme késleltetés nélkül végrehajtódik. Biztonsági okokból a lehető legkevesebb gépet érdemes fehérlistára tenni, vagy leginkább egyetlen egyet sem."
},
"nplurals=2; plural=(n != 1);");
