OC.L10N.register(
    "bruteforcesettings",
    {
    "Comment" : "Comentaris",
    "Add" : "Apondre",
    "Save" : "Enregistrar"
},
"nplurals=2; plural=(n > 1);");
