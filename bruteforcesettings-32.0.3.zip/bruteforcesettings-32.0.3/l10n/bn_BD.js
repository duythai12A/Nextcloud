OC.L10N.register(
    "bruteforcesettings",
    {
    "Comment" : "মন্তব্য",
    "Add" : "যোগ করুন",
    "Save" : "সংরক্ষণ"
},
"nplurals=2; plural=(n != 1);");
