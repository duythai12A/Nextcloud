OC.L10N.register(
    "bruteforcesettings",
    {
    "Brute-force settings" : "Paràmetres de la força bruta",
    "Whitelist IPs" : "Adreces IP permeses",
    "Comment" : "Comentari",
    "Add" : "Afegeix",
    "Save" : "Desar",
    "Brute-force IP whitelist" : "Llista d'IP permeses per a la força bruta",
    "To whitelist IP ranges from the brute-force protection specify them below. Note that any whitelisted IP can perform authentication attempts without any throttling. For security reasons, it is recommended to whitelist as few hosts as possible or ideally even none at all." : "Per a afegir intervals d'IP a la llista d'adreces permeses per a la protecció contra la força bruta, especifiqueu-les a continuació. Tingueu en compte que qualsevol adreça IP que s'indiqui aquí podrà fer intents d'autenticació sense cap limitació. Per seguretat, es recomana que n'indiqueu el mínim possible o, idealment, cap."
},
"nplurals=2; plural=(n != 1);");
