OC.L10N.register(
    "bruteforcesettings",
    {
    "Comment" : "Kommentaar",
    "Add" : "Voeg by",
    "Save" : "Stoor"
},
"nplurals=2; plural=(n != 1);");
