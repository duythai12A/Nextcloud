OC.L10N.register(
    "bruteforcesettings",
    {
    "Brute-force settings" : "تنظیمات Brute Force",
    "Whitelist IPs" : "IP های لیست سفید",
    "Comment" : "دیدگاه",
    "Add" : "افزودن",
    "Save" : "ذخیره",
    "Brute-force IP whitelist" : "لیست سفید IP با Brute-force",
    "To whitelist IP ranges from the brute-force protection specify them below. Note that any whitelisted IP can perform authentication attempts without any throttling. For security reasons, it is recommended to whitelist as few hosts as possible or ideally even none at all." : "برای محدوده IP لیست سفید از حفاظت ازbrute-force آنها را در زیر مشخص کنید. توجه داشته باشید که هر IP لیست سفید می تواند تلاشهای احراز هویت را بدون هیچ گونه ضربات انجام دهد. به دلایل امنیتی ، توصیه می شود لیست های میزبان کمترین تعداد ممکن یا ایده آل و حتی به هیچ وجه را انجام دهید."
},
"nplurals=2; plural=(n > 1);");
