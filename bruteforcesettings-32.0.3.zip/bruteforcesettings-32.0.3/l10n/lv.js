OC.L10N.register(
    "bruteforcesettings",
    {
    "Brute-force settings" : "Pārlases (brute-force) iestatījumi",
    "Whitelist IPs" : "Baltā saraksta IP adreses",
    "Comment" : "Piebilde",
    "Add" : "Pievienot",
    "Save" : "Saglabāt",
    "Brute-force IP whitelist" : "\"Brute-Force\" IP adrešu baltais saraksts",
    "To whitelist IP ranges from the brute-force protection specify them below. Note that any whitelisted IP can perform authentication attempts without any throttling. For security reasons, it is recommended to whitelist as few hosts as possible or ideally even none at all." : "Lai baltajā sarakstā iekļautu IP apgabalu no aizsardzības pret pārlases uzbrukuma, tie jānorāda zemāk. Jāņem vērā, ka jebkura baltajā sarakstā iekļautā IP adrese var veikt autentificēšanās mēģinājumus bez jebkādiem ierobežojumiem. Drošības apsvērumu dēļ ir ieteicams baltajā sarakstā iekļaut pēc iespējas mazāk saimniekdatoru vai vislabākajā gadījumā pat nevienu."
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n != 0 ? 1 : 2);");
