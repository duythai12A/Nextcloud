OC.L10N.register(
    "bruteforcesettings",
    {
    "Whitelist IPs" : "Дозволена листа на IP адреси",
    "Comment" : "Коментар",
    "Add" : "Додади",
    "Save" : "Сними"
},
"nplurals=2; plural=(n % 10 == 1 && n % 100 != 11) ? 0 : 1;");
