OC.L10N.register(
    "bruteforcesettings",
    {
    "Brute-force settings" : "Configuración escontra la fuercia bruta",
    "Whitelist IPs" : "IPs permitíes",
    "Your remote address was identified as \"{remoteAddress}\" and is bypassing brute-force protection." : "La to direición remota identificóse como «{remoteAddress}» y ta omitiendo la proteición escontra la fuercia bruta.",
    "IP address" : "Direición IP",
    "Mask" : "Mázcara",
    "Comment" : "Comentariu",
    "Add" : "Amestar",
    "Save" : "Guardar",
    "Delete entry for {subnet}" : "Desaniciar la entrada de {subnet}",
    "There was an error adding the IP to the whitelist." : "Hebo un error al amestar la direición a la llista d'IPs permitíes."
},
"nplurals=2; plural=(n != 1);");
