OC.L10N.register(
    "bruteforcesettings",
    {
    "Comment" : "ความคิดเห็น",
    "Add" : "เพิ่ม",
    "Save" : "บันทึก"
},
"nplurals=1; plural=0;");
