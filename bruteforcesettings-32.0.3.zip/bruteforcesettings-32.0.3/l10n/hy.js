OC.L10N.register(
    "bruteforcesettings",
    {
    "Comment" : "Մեկնաբանել",
    "Add" : "Ավելացնել",
    "Save" : "Պահպանել"
},
"nplurals=2; plural=(n != 1);");
