OC.L10N.register(
    "bruteforcesettings",
    {
    "Brute-force settings" : "Cài đặt Brute-force",
    "Comment" : "Bình luận",
    "Add" : "Thêm",
    "Save" : "Lưu",
    "Brute-force IP whitelist" : "Brute-force IP whitelist"
},
"nplurals=1; plural=0;");
