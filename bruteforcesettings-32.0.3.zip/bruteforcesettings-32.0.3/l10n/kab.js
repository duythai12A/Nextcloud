OC.L10N.register(
    "bruteforcesettings",
    {
    "Comment" : "Awennit",
    "Add" : "Rnu",
    "Save" : "Sekles"
},
"nplurals=2; plural=(n != 1);");
