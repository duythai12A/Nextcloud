OC.L10N.register(
    "bruteforcesettings",
    {
    "Add" : "﻿ಸೇರಿಸಿ",
    "Save" : "﻿ಉಳಿಸಿ"
},
"nplurals=2; plural=(n > 1);");
