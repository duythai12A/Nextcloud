OC.L10N.register(
    "bruteforcesettings",
    {
    "Brute-force settings" : "Brute-force ezarpenak",
    "Whitelist IPs" : "IP zerrenda zuria",
    "IP address" : "IP helbidea",
    "Mask" : "Maskara",
    "Comment" : "Iruzkindu",
    "Add" : "Gehitu",
    "Save" : "Gorde",
    "Brute-force IP whitelist" : "Brute-force IP zerrenda zuria",
    "To whitelist IP ranges from the brute-force protection specify them below. Note that any whitelisted IP can perform authentication attempts without any throttling. For security reasons, it is recommended to whitelist as few hosts as possible or ideally even none at all." : "IP barrutien  salbuespenen zerrenda zuria egiteko Brute-Force Protection horrek jakiteko, zehaztu salbuespenak. Jakin ezazu zerrenda zuriko IP horietatik mugarik gabe egin izango dutela sartzeko autentifikazioa. Seguritate arrazoiengatik, zerrenda zurian ahalik eta IP gutxien jartzea gomendatzen da. Hobe bat ere ez."
},
"nplurals=2; plural=(n != 1);");
