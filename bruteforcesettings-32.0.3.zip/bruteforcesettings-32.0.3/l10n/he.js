OC.L10N.register(
    "bruteforcesettings",
    {
    "Brute-force settings" : "הגדרות כוח ברוטלי",
    "Whitelist IPs" : "כתובות IP ברשימת היתר",
    "Comment" : "הערה",
    "Add" : "הוספה",
    "Save" : "שמירה",
    "Brute-force IP whitelist" : "רשימת היתר IP לכוח ברוטלי"
},
"nplurals=3; plural=(n == 1 && n % 1 == 0) ? 0 : (n == 2 && n % 1 == 0) ? 1: 2;");
