OC.L10N.register(
    "bruteforcesettings",
    {
    "Comment" : "Izoh",
    "Add" : "Add",
    "Save" : "Saqlash"
},
"nplurals=1; plural=0;");
