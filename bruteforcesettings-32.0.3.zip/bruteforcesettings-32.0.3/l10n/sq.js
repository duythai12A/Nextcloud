OC.L10N.register(
    "bruteforcesettings",
    {
    "Brute-force settings" : "Konfigurimet e brute-force",
    "Comment" : "Koment",
    "Add" : "Shto",
    "Save" : "Ruaje",
    "Brute-force IP whitelist" : "Brute-force listën e bardhë të IP-ve "
},
"nplurals=2; plural=(n != 1);");
