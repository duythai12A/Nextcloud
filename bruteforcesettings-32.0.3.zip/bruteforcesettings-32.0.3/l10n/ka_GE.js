OC.L10N.register(
    "bruteforcesettings",
    {
    "Brute-force settings" : "Brute-force-ის პარამეტრები",
    "Comment" : "კომენტარი",
    "Add" : "დამატება",
    "Save" : "შენახვა",
    "Brute-force IP whitelist" : "Brute-force-ის IP whitelist-ი"
},
"nplurals=2; plural=(n!=1);");
