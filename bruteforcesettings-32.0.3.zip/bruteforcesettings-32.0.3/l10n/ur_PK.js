OC.L10N.register(
    "bruteforcesettings",
    {
    "Add" : "شامل کریں",
    "Save" : "حفظ"
},
"nplurals=2; plural=(n != 1);");
