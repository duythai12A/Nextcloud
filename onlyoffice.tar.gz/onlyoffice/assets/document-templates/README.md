## Overview

Template files used to create new documents and documents with sample content in:

- [ONLYOFFICE app for Nextcloud](https://github.com/ONLYOFFICE/onlyoffice-nextcloud)
- [ONLYOFFICE app for Odoo](https://github.com/onlyoffice/onlyoffice-odoo)
- [ONLYOFFICE app for ownCloud](https://github.com/onlyoffice/onlyoffice-owncloud)
- [ONLYOFFICE app for Pipedrive](https://github.com/onlyoffice/onlyoffice-pipedrive)
- [ONLYOFFICE addon for Plone](https://github.com/onlyoffice/onlyoffice-plone)
- [ONLYOFFICE Docs Integration PHP SDK](https://github.com/ONLYOFFICE/docs-integration-sdk-php)
- [ONLYOFFICE DocSpace app for Zoom](https://github.com/onlyoffice/onlyoffice-docspace-zoom)
- [ONLYOFFICE module for HumHub](https://github.com/ONLYOFFICE/onlyoffice-humhub)
