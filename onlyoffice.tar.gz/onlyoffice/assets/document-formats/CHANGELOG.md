# Change Log

## 3.0.0
- diagram documentType for vsdx, vssx, vstx, vsdm, vssm, vstm
- view odg, md
- edit xlsb

## 2.1.0
- hwp, hwpx formats
- pages, numbers, key formats

## 2.0.0
- pdf documentType for djvu,  docxf, oform, oxps, pdf, xps
- fb2 additional mime

## 1.1.0
- filling pdf
- conversion formats for txt, csv
- formats for auto conversion

## 1.0.0
- formats for viewing, editing and lossy editing
- formats for conversions
- mime-types of formats
