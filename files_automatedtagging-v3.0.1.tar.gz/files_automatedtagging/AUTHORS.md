<!--
  - SPDX-FileCopyrightText: 2024 Nextcloud GmbH and Nextcloud contributors
  - SPDX-License-Identifier: CC0-1.0
-->
# Authors

- Arthur Schiwon <blizzz@arthur-schiwon.de>
- Joas Schilling <coding@schilljs.com>
- Julius Härtl <jus@bitgrid.net>
- Robin Appelman <robin@icewind.nl>
