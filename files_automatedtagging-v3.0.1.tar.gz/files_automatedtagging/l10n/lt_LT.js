OC.L10N.register(
    "files_automatedtagging",
    {
    "No tags given" : "Nepriskirta jokių žymų",
    "At least one of the given tags is invalid" : "Bent viena iš žymų yra netinkama",
    "Automated tagging" : "Automatinis žymų priskyrimas",
    "Automated tagging of files" : "Automatinis žymų priskyrimas failams",
    "File is changed" : "Failas yra pakeistas",
    "Automatically tag files based on factors such as filetype, user group memberships, time and more." : "Automatiškai priskirti failams žymas pagal tokius faktorius kaip failo tipas, naudotojų grupė, narystės, laikas ir kt.",
    "Each rule group consists of one or more rules. A request matches a group if all rules evaluate to true. On uploading a file all defined groups are evaluated and when matching, the given collaborative tags are assigned to the file." : "Kiekvieną taisyklių grupę sudaro viena ar daugiau taisyklių. Užklausa atitinka grupę, jei tenkina visų taisyklių sąlygas. Įkeliant failą yra įvertinamos visos apibrėžtos grupės, o suderinus – failui priskiriamos nurodytos žymos.",
    "Files automated tagging" : "Automatinis žymų priskyrimas failams",
    "Automatically assign collaborative tags to files based on conditions" : "Automatiškai priskirti bendradarbiavimo žymas failams, remiantis sąlygomis",
    "An app for Nextcloud that automatically assigns tags to newly uploaded files based on some conditions.\n\nThe tags can later be used to control retention, file access, automatic script execution and more.\n\n## How it works\nTo define tags, administrators can create and manage a set of rule groups. Each rule group consists of one or more rules combined through operators. Rules can include criteria like file type, size, time and more. A request matches a group if all rules evaluate to true. On uploading a file all defined groups are evaluated and when matching, the given tags are assigned to the file." : "„Nextcloud“ programa, kuri atsižvelgdama į tam tikras sąlygas, automatiškai priskiria žymas naujai išsiųstiems failams.\n\nŽymos gali būti naudojamos siekiant valdyti išlaikymą, prieigą prie failų, automatinį scenarijų vykdymą ir kt.\n\n## Kaip tai veikia\nNorėdami priskirti žymas, administratoriai gali sukurti ir tvarkyti taisyklių grupių rinkinį. Kiekvieną taisyklių grupę sudaro viena ar daugiau taisyklių, sujungtų operatoriais. Taisyklėse gali būti tokie kriterijai kaip failo tipas, dydis, laikas ir kt. Užklausa atitinka grupę tuo atveju, jei yra tenkinamos visos taisyklės. Išsiunčiant failą įvertinamos visos apibrėžtos grupės, o atradus atitiktį – failui priskiriamos nurodytos žymos.",
    "Tag a file" : "Priskirti failui žymą"
},
"nplurals=4; plural=(n % 10 == 1 && (n % 100 > 19 || n % 100 < 11) ? 0 : (n % 10 >= 2 && n % 10 <=9) && (n % 100 > 19 || n % 100 < 11) ? 1 : n % 1 != 0 ? 2: 3);");
