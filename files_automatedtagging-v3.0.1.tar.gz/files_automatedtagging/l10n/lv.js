OC.L10N.register(
    "files_automatedtagging",
    {
    "No tags given" : "Nav piešķirtas birkas",
    "At least one of the given tags is invalid" : "Vismaz vienu no birkām ir nederīga",
    "Files automated tagging" : "Datņu automātiska atzīmēšana"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n != 0 ? 1 : 2);");
