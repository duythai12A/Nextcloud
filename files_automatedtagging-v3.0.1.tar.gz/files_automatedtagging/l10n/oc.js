OC.L10N.register(
    "files_automatedtagging",
    {
    "No tags given" : "Cap d’etiqueta pas donada"
},
"nplurals=2; plural=(n > 1);");
