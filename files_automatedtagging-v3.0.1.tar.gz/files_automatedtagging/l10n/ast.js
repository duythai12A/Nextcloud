OC.L10N.register(
    "files_automatedtagging",
    {
    "File is changed" : "El ficheru camudó"
},
"nplurals=2; plural=(n != 1);");
