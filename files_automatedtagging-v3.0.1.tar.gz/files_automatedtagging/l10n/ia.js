OC.L10N.register(
    "files_automatedtagging",
    {
    "No tags given" : "Nulle etiquettas prefixate",
    "At least one of the given tags is invalid" : "Al minus un del etiquettas prefixate non es valide",
    "Each rule group consists of one or more rules. A request matches a group if all rules evaluate to true. On uploading a file all defined groups are evaluated and when matching, the given collaborative tags are assigned to the file." : "Cata gruppo de regulas consiste in un o plus regulas. Un requesta corresponde a un gruppo si tote le regulas es evalutate como ver. Quando incargar un file, tote le gruppos definite es evalutate e quando illos corresponde, le etiquettas collaborative prefixate es assignate al file.",
    "Files automated tagging" : "Files etiquettate automaticamente"
},
"nplurals=2; plural=(n != 1);");
