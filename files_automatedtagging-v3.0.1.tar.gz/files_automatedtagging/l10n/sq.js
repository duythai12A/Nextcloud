OC.L10N.register(
    "files_automatedtagging",
    {
    "No tags given" : "Asnjë etiketë e dhënë",
    "At least one of the given tags is invalid" : "Të paktën njëra nga etiketat e dhëna është e pavlefshme",
    "Automatically tag files based on factors such as filetype, user group memberships, time and more." : "Etiketo automatikisht skedaret duke u bazuar në rrethana si lloji i skedarit, anëtarësimet e grupit të përdoruesve, koha dhe të tjera.",
    "Each rule group consists of one or more rules. A request matches a group if all rules evaluate to true. On uploading a file all defined groups are evaluated and when matching, the given collaborative tags are assigned to the file." : "Çdo grup rregullash konsiston në një ose më shumë rregulla. Një kërkesë përputhet me një grup nëse të gjitha rregullat vlerësohen si të vërteta. Gjatë ngarkimit të një skedari të gjitha grupet e përcaktuara vlerësohen dhe kur ato përputhen, etiketat e dhëna të bashkëpunimit i caktohen skedarit.",
    "Files automated tagging" : "Skedar me etiketim të automatizuar"
},
"nplurals=2; plural=(n != 1);");
