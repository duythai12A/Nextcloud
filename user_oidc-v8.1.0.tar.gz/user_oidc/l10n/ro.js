OC.L10N.register(
    "user_oidc",
    {
    "Error" : "Eroare",
    "Access forbidden" : "Acces restricționat",
    "Client ID" : "ID client",
    "Update" : "Actualizare",
    "Remove" : "Elimină",
    "Cancel" : "Anulare",
    "Delete" : "Șterge",
    "Submit" : "Trimite",
    "Client secret" : "Secret client",
    "Scope" : "Scop",
    "Back to %s" : "Înapoi la %s",
    "Domain" : "Domeniu"
},
"nplurals=3; plural=(n==1?0:(((n%100>19)||((n%100==0)&&(n!=0)))?2:1));");
