OC.L10N.register(
    "user_oidc",
    {
    "Access forbidden" : "Toegang verbode",
    "Client ID" : "Klant-ID",
    "Update" : "Werk by",
    "Cancel" : "Cancel",
    "Delete" : "Skrap",
    "Submit" : "Dien in",
    "Back to %s" : "Terug na %s"
},
"nplurals=2; plural=(n != 1);");
