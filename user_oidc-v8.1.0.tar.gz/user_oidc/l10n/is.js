OC.L10N.register(
    "user_oidc",
    {
    "Error" : "Villa",
    "Access forbidden" : "Aðgangur bannaður",
    "Client ID" : "Biðlaraauðkenni",
    "Update" : "Uppfæra",
    "Remove" : "Fjarlægja",
    "Confirm deletion" : "Staðfesta eyðingu",
    "Cancel" : "Hætta við",
    "Delete" : "Eyða",
    "Submit" : "Senda inn",
    "Client secret" : "Leynilykill biðlara",
    "Scope" : "Umfang",
    "Attribute mapping" : "Vörpun eiginda",
    "Back to %s" : "Til baka í %s",
    "Domain" : "Lén"
},
"nplurals=2; plural=(n % 10 != 1 || n % 100 == 11);");
