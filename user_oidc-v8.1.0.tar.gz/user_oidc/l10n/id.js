OC.L10N.register(
    "user_oidc",
    {
    "Error" : "Galat",
    "Access forbidden" : "Akses ditolak",
    "Client ID" : "ID Klien",
    "Update" : "Perbarui",
    "Remove" : "Hapus",
    "Cancel" : "Batal",
    "Delete" : "Hapus",
    "Client secret" : "Rahasia klien",
    "Scope" : "Skop",
    "Back to %s" : "Kembali ke %s",
    "Domain" : "Domain"
},
"nplurals=1; plural=0;");
