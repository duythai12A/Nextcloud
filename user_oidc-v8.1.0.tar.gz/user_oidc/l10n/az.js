OC.L10N.register(
    "user_oidc",
    {
    "Error" : "Səhv",
    "Client ID" : "Müştəri İD-s",
    "Update" : "Yenilənmə",
    "Cancel" : "Cancel",
    "Delete" : "Sil",
    "Client secret" : "Müxtəri sirri",
    "Scope" : "Həcm",
    "Domain" : "Domen"
},
"nplurals=2; plural=(n != 1);");
