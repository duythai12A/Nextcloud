OC.L10N.register(
    "user_oidc",
    {
    "Error" : "Gabim",
    "Access forbidden" : "Ndalohet hyrja",
    "Client ID" : "ID klienti",
    "Update" : "Përditëso",
    "Remove" : "Hiqe",
    "Cancel" : "Anuloje",
    "Delete" : "Fshi",
    "Submit" : "Dërgo",
    "Client secret" : "E fshehtë klienti",
    "Scope" : "Shtrirje",
    "Attribute mapping" : "Përcaktimi i atributeve",
    "Domain" : "Përkatësi"
},
"nplurals=2; plural=(n != 1);");
