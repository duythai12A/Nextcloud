OC.L10N.register(
    "user_oidc",
    {
    "Error" : "Xatolik",
    "Access forbidden" : "Kirish taqiqlangan",
    "Client ID" : "Mijoz identifikatori",
    "Update" : "Yangilash",
    "Remove" : "O'chirish",
    "Cancel" : "Bekor qilish",
    "Delete" : "O'chirish",
    "Submit" : "Submit",
    "Back to %s" : "%sga qaytish"
},
"nplurals=1; plural=0;");
