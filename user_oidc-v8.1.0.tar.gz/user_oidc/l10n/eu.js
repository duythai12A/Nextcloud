OC.L10N.register(
    "user_oidc",
    {
    "Error" : "Errorea",
    "Access forbidden" : "Sarrera debekatuta",
    "Client ID" : "Bezeroaren IDa",
    "Update" : "Eguneratu",
    "Remove" : "Kendu",
    "Confirm deletion" : "Berretsi ezabaketa",
    "Cancel" : "Utzi",
    "Delete" : "Ezabatu",
    "Submit" : "Bidali",
    "Client secret" : "Bezeroaren sekretua",
    "Scope" : "Esparrua",
    "Attribute mapping" : "Atributu-esleitzea",
    "Back to %s" : "Itzuli %s(e)ra",
    "Domain" : "Domeinua"
},
"nplurals=2; plural=(n != 1);");
