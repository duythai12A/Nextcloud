OC.L10N.register(
    "user_oidc",
    {
    "Error" : "Error",
    "Access forbidden" : "Prohíbese l'accesu",
    "Client ID" : "ID de veceru",
    "Update" : "Anovar",
    "Remove" : "Quitar",
    "Confirm deletion" : "Confirmar el desaniciu",
    "Cancel" : "Encaboxar",
    "Delete" : "Desaniciar",
    "Submit" : "Unviar",
    "Client secret" : "Secretu de veceru",
    "Scope" : "Ámbitu",
    "Attribute mapping" : "Mapéu d'atributos",
    "Back to %s" : "Volver a «%s»",
    "Domain" : "Dominiu"
},
"nplurals=2; plural=(n != 1);");
