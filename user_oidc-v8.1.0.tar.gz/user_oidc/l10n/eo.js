OC.L10N.register(
    "user_oidc",
    {
    "Error" : "Eraro",
    "Access forbidden" : "Aliro estas malpermesata",
    "Client ID" : "Klientidentigilo",
    "Update" : "Ĝisdatigi",
    "Cancel" : "Cancel",
    "Delete" : "Forigi",
    "Submit" : "Sendi",
    "Client secret" : "Klientosekreto",
    "Scope" : "Amplekso",
    "Back to %s" : "Antaŭen al %s",
    "Domain" : "Domajno"
},
"nplurals=2; plural=(n != 1);");
