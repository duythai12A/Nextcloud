OC.L10N.register(
    "user_oidc",
    {
    "Error" : "Алдаа",
    "Access forbidden" : "Хандах эрхгүй",
    "Client ID" : "Хэрэглэгчийн ID",
    "Cancel" : "Цуцлах",
    "Delete" : "Устгах",
    "Submit" : "мэдэгдэх"
},
"nplurals=2; plural=(n != 1);");
