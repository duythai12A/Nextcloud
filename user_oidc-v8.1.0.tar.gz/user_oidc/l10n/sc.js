OC.L10N.register(
    "user_oidc",
    {
    "Error" : "Errore",
    "Access forbidden" : "Atzessu proibidu",
    "Client ID" : "ID cliente",
    "Update" : "Agiorna",
    "Remove" : "Boga",
    "Cancel" : "Annulla",
    "Delete" : "Cantzella",
    "Submit" : "Imbia",
    "Client secret" : "Segretu de su cliente",
    "Scope" : "Àmbitu",
    "Attribute mapping" : "Assòtziu de is atributos",
    "Back to %s" : "Torra a %s",
    "Domain" : "Domìniu"
},
"nplurals=2; plural=(n != 1);");
