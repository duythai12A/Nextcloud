OC.L10N.register(
    "user_oidc",
    {
    "Error" : "Lỗi",
    "Access forbidden" : "Truy cập bị cấm",
    "Client ID" : "ID khách hàng",
    "Update" : "Cập nhật",
    "Remove" : "Xoá",
    "Confirm deletion" : "Xác nhận xoá",
    "Cancel" : "Hủy bỏ",
    "Delete" : "Xóa",
    "Submit" : "Gửi",
    "Back to %s" : "Quay lại %s",
    "Domain" : "Miền"
},
"nplurals=1; plural=0;");
