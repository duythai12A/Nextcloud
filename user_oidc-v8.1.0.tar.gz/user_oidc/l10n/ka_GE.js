OC.L10N.register(
    "user_oidc",
    {
    "Error" : "შეცდომა",
    "Access forbidden" : "წვდომა აკრძალულია",
    "Client ID" : "კლიენტის ID",
    "Update" : "განახლება",
    "Cancel" : "გაუქმება",
    "Delete" : "წაშლა",
    "Submit" : "გაგზავნა",
    "Client secret" : "კლიენტის საიდუმლო",
    "Scope" : "ფარგლები",
    "Attribute mapping" : "ატრიბუტების ბმები",
    "Domain" : "დომენი"
},
"nplurals=2; plural=(n!=1);");
