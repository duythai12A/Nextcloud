OC.L10N.register(
    "user_oidc",
    {
    "Error" : "Fehler",
    "Access forbidden" : "Zougrëff net erlaabt",
    "Client ID" : "Client ID",
    "Update" : "Update",
    "Cancel" : "Cancel",
    "Delete" : "Läschen"
},
"nplurals=2; plural=(n != 1);");
