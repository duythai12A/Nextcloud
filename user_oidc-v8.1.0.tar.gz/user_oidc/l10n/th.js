OC.L10N.register(
    "user_oidc",
    {
    "Error" : "ข้อผิดพลาด",
    "Access forbidden" : "ไม่ได้รับอนุญาตให้เข้าถึง",
    "Client ID" : "รหัสไคลเอ็นต์",
    "Update" : "อัปเดต",
    "Remove" : "ลบออก",
    "Cancel" : "ยกเลิก",
    "Delete" : "ลบ",
    "Submit" : "ส่ง",
    "Client secret" : "ข้อมูลลับไคลเอ็นต์",
    "Scope" : "ขอบเขต",
    "Back to %s" : "กลับสู่ %s",
    "Domain" : "โดเมน"
},
"nplurals=1; plural=0;");
