OC.L10N.register(
    "user_oidc",
    {
    "Error" : "Feil",
    "Access forbidden" : "Tilgang forbudt",
    "Client ID" : "Klient-ID",
    "Update" : "Oppdater",
    "Cancel" : "Cancel",
    "Delete" : "Slett"
},
"nplurals=2; plural=(n != 1);");
