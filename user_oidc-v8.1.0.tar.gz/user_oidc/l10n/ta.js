OC.L10N.register(
    "user_oidc",
    {
    "Error" : "வழு",
    "Access forbidden" : "அணுக தடை",
    "Update" : "இற்றைப்படுத்தல்",
    "Remove" : "அகற்றுக",
    "Cancel" : "ரத்து செய்",
    "Delete" : "நீக்குக"
},
"nplurals=2; plural=(n != 1);");
