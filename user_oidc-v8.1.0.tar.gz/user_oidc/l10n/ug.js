OC.L10N.register(
    "user_oidc",
    {
    "Error" : "خاتالىق",
    "Access forbidden" : "زىيارەت قىلىش چەكلەنگەن",
    "Client ID" : "Client ID",
    "Update" : "يېڭىلاش",
    "Remove" : "ئۆچۈرۈڭ",
    "Confirm deletion" : "ئۆچۈرۈشنى جەزملەشتۈرۈڭ",
    "Cancel" : "بىكار قىلىش",
    "Delete" : "ئۆچۈر",
    "Submit" : "يوللاڭ",
    "Client secret" : "Client secret",
    "Scope" : "دائىرىسى",
    "Attribute mapping" : "خەرىتە سىزىش",
    "Back to %s" : "% S گە قايتىش",
    "Domain" : "Domain"
},
"nplurals=2; plural=(n != 1);");
