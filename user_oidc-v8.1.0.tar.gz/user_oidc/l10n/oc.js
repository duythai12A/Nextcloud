OC.L10N.register(
    "user_oidc",
    {
    "Error" : "Error",
    "Access forbidden" : "Accès defendut",
    "Client ID" : "ID client",
    "Update" : "Actualizar",
    "Remove" : "Suprimir",
    "Cancel" : "Anullar",
    "Delete" : "Suprimir",
    "Submit" : "Transmetre",
    "Back to %s" : "Tornar a %s"
},
"nplurals=2; plural=(n > 1);");
