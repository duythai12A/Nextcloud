OC.L10N.register(
    "user_oidc",
    {
    "Error" : "Error",
    "Access forbidden" : "Access forbidden",
    "Client ID" : "Client ID",
    "Update" : "Update",
    "Remove" : "Remove",
    "Cancel" : "Cancel",
    "Delete" : "წაშლა",
    "Submit" : "Submit",
    "Client secret" : "Client secret",
    "Scope" : "Scope",
    "Attribute mapping" : "Attribute mapping",
    "Back to %s" : "Back to %s",
    "Domain" : "Domain"
},
"nplurals=2; plural=(n!=1);");
