<?php
declare(strict_types=1);

// SPDX-FileCopyrightText: 2022 Carl Schwan <carl@carlschwan.eu>
// SPDX-License-Identifier: AGPL-3.0-or-later

namespace OCA\VDriveChristmas\AppInfo;

use OCP\Util;
use OCP\AppFramework\App;
use OCP\AppFramework\Bootstrap\IBootContext;
use OCP\AppFramework\Bootstrap\IBootstrap;
use OCP\AppFramework\Bootstrap\IRegistrationContext;
use OCP\IConfig;

class Application extends App implements IBootstrap {
	public const APP_ID = 'vdrive_christmas';

	public function __construct(array $urlParams = []) {
		parent::__construct(self::APP_ID, $urlParams);
	}

	public function register(IRegistrationContext $context): void {
		/**
		 * Set primary color for theming (vDrive Christmas)
		 * @var IConfig $config
		 */
		$config = \OC::$server->get(IConfig::class);

		// Đỏ Noel (khớp CSS: --color-primary)
		$config->setAppValue('theming', 'color', '#b91c1c');
	}

	public function boot(IBootContext $context): void {
		Util::addStyle(self::APP_ID, 'style');

		// pride.js đã bỏ → không load nữa
		// Util::addScript(self::APP_ID, 'pride');
	}
}
