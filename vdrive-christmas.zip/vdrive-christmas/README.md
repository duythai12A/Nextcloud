# Pride :rainbow_flag: :rainbow:
![Downloads](https://img.shields.io/github/downloads/skjnldsv/pride/total?style=flat-square)

Show your pride to the world and to your nextcloud instance!

![screenshot](https://github.com/skjnldsv/pride/raw/master/screenshot.png)

Place this app in **nextcloud/apps/**

# How to publish
1. Tag appropriate commit on this repository
2. Push the new tag to this repository
3. Create release on this repository
