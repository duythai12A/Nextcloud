OC.L10N.register(
    "files_accesscontrol",
    {
    "No rule given" : "Nema propisanog pravila",
    "Block access to a file" : "Blokiraj pristup datoteci",
    "File is accessed" : "Datoteci je pristupljeno",
    "File access control" : "Kontrola pristupa datotekama",
    "Control access to files based on conditions" : "Kontroliraj pristup datotekama na temelju uvjeta"
},
"nplurals=3; plural=n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2;");
