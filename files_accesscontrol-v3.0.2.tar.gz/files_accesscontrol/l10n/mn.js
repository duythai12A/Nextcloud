OC.L10N.register(
    "files_accesscontrol",
    {
    "No rule given" : "Дүрэм заагаагүй байна",
    "File access control" : " Файлд хандах эрхийн удирдлага"
},
"nplurals=2; plural=(n != 1);");
