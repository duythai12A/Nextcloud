OC.L10N.register(
    "files_accesscontrol",
    {
    "No rule given" : "Sääntö puuttuu",
    "Block access to a file" : "Estä pääsy tiedostoon",
    "File is accessed" : "Tiedostoa käytetään",
    "File access control" : "Tiedostojen pääsynhallinta",
    "Control access to files based on conditions" : "Hallitse pääsyä tiedostoihin ehtoihin pohjautuen"
},
"nplurals=2; plural=(n != 1);");
