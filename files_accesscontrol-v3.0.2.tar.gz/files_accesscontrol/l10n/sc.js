OC.L10N.register(
    "files_accesscontrol",
    {
    "No rule given" : "Peruna règula frunida",
    "Block access to a file" : "Bloca s'atzessu a unu documentu",
    "File is accessed" : "Su documentu est abertu",
    "File access control" : "Controllu de atzessu a su documentu",
    "Control access to files based on conditions" : "Su controllu de s'atzessu a is documentos basadu in cunditziones"
},
"nplurals=2; plural=(n != 1);");
