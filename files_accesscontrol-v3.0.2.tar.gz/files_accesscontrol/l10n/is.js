OC.L10N.register(
    "files_accesscontrol",
    {
    "No rule given" : "Engin regla gefin",
    "Block access to a file" : "Loka á aðgang að skrá",
    "File is accessed" : "Aðgangur er að skrá",
    "File access control" : "Aðgangsstýring skráa",
    "Control access to files based on conditions" : "Stýrðu aðgangi að skrám með skilyrðum"
},
"nplurals=2; plural=(n % 10 != 1 || n % 100 == 11);");
