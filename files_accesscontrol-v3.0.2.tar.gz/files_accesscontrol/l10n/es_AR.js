OC.L10N.register(
    "files_accesscontrol",
    {
    "No rule given" : "No hay una regla dada",
    "File access control" : "Control de acceso de archivos"
},
"nplurals=3; plural=n == 1 ? 0 : n != 0 && n % 1000000 == 0 ? 1 : 2;");
