OC.L10N.register(
    "files_accesscontrol",
    {
    "No rule given" : "Tidak ada peraturan yang diberikan",
    "File access control" : "Akses kontrol berkas"
},
"nplurals=1; plural=0;");
