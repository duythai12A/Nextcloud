OC.L10N.register(
    "files_accesscontrol",
    {
    "No rule given" : "Nav piešķirts nosacījums",
    "File access control" : "Datņu pieejas kontrole",
    "Control access to files based on conditions" : "Pārvaldi datņu piekļuvi pēc nosacījumiem"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n != 0 ? 1 : 2);");
