OC.L10N.register(
    "files_accesscontrol",
    {
    "No rule given" : "Nulle regula prefixate",
    "File access control" : "Controlo de accesso a file"
},
"nplurals=2; plural=(n != 1);");
