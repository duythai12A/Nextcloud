OC.L10N.register(
    "files_accesscontrol",
    {
    "No rule given" : "Reeglit pole määratud",
    "Block access to a file" : "Blokeeri ligipääs failile",
    "File is accessed" : "Failile on ligi pääsetud",
    "File access control" : "Failide ligipääsukontroll",
    "Control access to files based on conditions" : "Kontrolli konkreetsete tingimuste alusel ligipääsu failidele"
},
"nplurals=2; plural=(n != 1);");
