OC.L10N.register(
    "files_accesscontrol",
    {
    "No rule given" : "Neniu regulo donita",
    "Block access to a file" : "Bloki aliron al dosiero",
    "File is accessed" : "Dosiero estas atingita",
    "File access control" : "Dosieran alirkontrolo",
    "Control access to files based on conditions" : "Alikontrolo al dosieroj laŭ kondiĉoj"
},
"nplurals=2; plural=(n != 1);");
