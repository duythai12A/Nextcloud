OC.L10N.register(
    "files_accesscontrol",
    {
    "No rule given" : "Nenhuma regra definida",
    "Block access to a file" : "Bloquear o acesso ao ficheiro",
    "File is accessed" : "Ficheiro é acedido",
    "File access control" : "Controlo de acesso de ficheiro",
    "Control access to files based on conditions" : "Controlar o acesso aos ficheiros com base nas condições"
},
"nplurals=3; plural=(n == 0 || n == 1) ? 0 : n != 0 && n % 1000000 == 0 ? 1 : 2;");
