OC.L10N.register(
    "files_accesscontrol",
    {
    "No rule given" : "No rule given"
},
"nplurals=1; plural=0;");
