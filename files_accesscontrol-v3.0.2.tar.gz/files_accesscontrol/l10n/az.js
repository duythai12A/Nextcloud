OC.L10N.register(
    "files_accesscontrol",
    {
    "No rule given" : "Heç bir qayda verilməyib",
    "Block access to a file" : "Fayla icazəni blokla",
    "File is accessed" : "Fayla icazə var",
    "File access control" : "Fayl icazəsinin idarə edilməsi",
    "Control access to files based on conditions" : "Fayllara icazəni şərtlərlə idarə et"
},
"nplurals=2; plural=(n != 1);");
