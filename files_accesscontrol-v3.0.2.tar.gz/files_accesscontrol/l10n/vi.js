OC.L10N.register(
    "files_accesscontrol",
    {
    "File access control" : "Quản lý truy cập tập tin"
},
"nplurals=1; plural=0;");
