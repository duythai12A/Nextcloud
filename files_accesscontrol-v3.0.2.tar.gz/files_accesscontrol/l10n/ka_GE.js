OC.L10N.register(
    "files_accesscontrol",
    {
    "No rule given" : "წესი არაა მოცემული",
    "File access control" : "ფაილის წვდომის კონტროლი"
},
"nplurals=2; plural=(n!=1);");
