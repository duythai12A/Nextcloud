OC.L10N.register(
    "files_accesscontrol",
    {
    "No rule given" : "Keng Regel festgeluecht",
    "File access control" : "Zougrëffskontroll"
},
"nplurals=2; plural=(n != 1);");
