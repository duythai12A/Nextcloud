OC.L10N.register(
    "files_accesscontrol",
    {
    "No rule given" : "Asnjë rregull i dhënë",
    "File access control" : "Kontrolli i aksesit të skedarëve",
    "Control access to files based on conditions" : "Lejim të kontrollit të skedarëve sipas kushteve"
},
"nplurals=2; plural=(n != 1);");
