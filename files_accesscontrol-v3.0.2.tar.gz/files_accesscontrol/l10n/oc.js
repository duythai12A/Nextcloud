OC.L10N.register(
    "files_accesscontrol",
    {
    "No rule given" : "Cap de règla pas donada"
},
"nplurals=2; plural=(n > 1);");
