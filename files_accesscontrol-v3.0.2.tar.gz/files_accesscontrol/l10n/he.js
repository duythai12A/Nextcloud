OC.L10N.register(
    "files_accesscontrol",
    {
    "No rule given" : "לא צוין כל",
    "Block access to a file" : "חסימת גישה לקובץ",
    "File is accessed" : "מתבצעת גישה לקובץ",
    "File access control" : "בקרת גישה לקבצים",
    "Control access to files based on conditions" : "שליטה על הגישה לקבצים שלך לפי תנאים מסוימים"
},
"nplurals=3; plural=(n == 1 && n % 1 == 0) ? 0 : (n == 2 && n % 1 == 0) ? 1: 2;");
