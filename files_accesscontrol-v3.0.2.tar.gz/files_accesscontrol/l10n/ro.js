OC.L10N.register(
    "files_accesscontrol",
    {
    "No rule given" : "Nicio regulă definită",
    "Block access to a file" : "Blochează accesul la fișier",
    "File is accessed" : "Fișierul este accesat",
    "File access control" : "Control acces fișiere",
    "Control access to files based on conditions" : "Controlează accesul la fișiere în funcție de anumite condiții"
},
"nplurals=3; plural=(n==1?0:(((n%100>19)||((n%100==0)&&(n!=0)))?2:1));");
