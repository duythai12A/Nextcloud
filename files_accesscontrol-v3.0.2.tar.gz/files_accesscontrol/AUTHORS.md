<!--
  - SPDX-FileCopyrightText: 2024 Nextcloud GmbH and Nextcloud contributors
  - SPDX-License-Identifier: CC0-1.0
-->
# Authors

- Arthur Schiwon <blizzz@arthur-schiwon.de>
- Christoph Wurst <christoph@winzerhof-wurst.at>
- David Toledo <dtoledo@solidgear.es>
- Joas Schilling <coding@schilljs.com>
- John Molakvoæ <skjnldsv@protonmail.com>
- Lukas Reschke <lukas@statuscode.ch>
- Morris Jobke <hey@morrisjobke.de>
- Robin Appelman <robin@icewind.nl>
- Roeland Jago Douma <roeland@famdouma.nl>
- Sergio Bertolín <sbertolin@solidgear.es>
- Thomas Müller <thomas.mueller@tmit.eu>
- Vincent Petry <vincent@nextcloud.com>
