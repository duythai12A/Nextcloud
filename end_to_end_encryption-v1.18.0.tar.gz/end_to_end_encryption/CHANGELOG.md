<!--
  - SPDX-FileCopyrightText: 2022 Nextcloud GmbH and Nextcloud contributors
  - SPDX-License-Identifier: AGPL-3.0-or-later
-->
## Release 1.11.0-beta.1

- Compatibility with NC 25
- Large performance improvement in the dav plugins
- Allow user to delete their own keys from the settings
- Allow admin to limit who (list of groups) can use the app
- Make user agents allowed to interact with e2ee configurable by admin
- Updated translations
