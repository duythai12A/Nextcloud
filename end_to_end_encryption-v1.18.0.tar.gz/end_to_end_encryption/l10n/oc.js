OC.L10N.register(
    "end_to_end_encryption",
    {
    "End-to-End Encryption" : "Chiframent del cap a la fin",
    "Limit to groups" : "Limitar als grops",
    "Save" : "Enregistrar",
    "Submit" : "Transmetre",
    "Cancel" : "Anullar",
    "Close" : "Plegar"
},
"nplurals=2; plural=(n > 1);");
