OC.L10N.register(
    "end_to_end_encryption",
    {
    "Internal error" : "Kesalahan internal",
    "File not locked" : "File tidak dikunci",
    "Limit to groups" : "Batasi ke grup",
    "Limit app usage to groups" : "Batas pemakaian aplikasi untuk grup",
    "Save" : "Simpan",
    "Cancel" : "Batal",
    "Close" : "Tutup",
    "Select or drop files" : "Pilih atau drop berkas"
},
"nplurals=1; plural=0;");
