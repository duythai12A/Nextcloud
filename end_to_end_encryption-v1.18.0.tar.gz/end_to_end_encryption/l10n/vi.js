OC.L10N.register(
    "end_to_end_encryption",
    {
    "Internal error" : "Lỗi nội bộ",
    "Limit to groups" : "Giới hạn nhóm",
    "Limit app usage to groups" : "Giới hạn sử dụng ứng dụng cho các nhóm",
    "Save" : "Lưu",
    "Submit" : "Gửi",
    "Cancel" : "Hủy",
    "Close" : "Đóng",
    "Select or drop files" : "Chọn hoặc thả tập tin"
},
"nplurals=1; plural=0;");
