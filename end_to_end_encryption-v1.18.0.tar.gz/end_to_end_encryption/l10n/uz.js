OC.L10N.register(
    "end_to_end_encryption",
    {
    "Internal error" : "Ichki xato",
    "End-to-End Encryption" : "End-to-end shifrlash",
    "Save" : "Save",
    "Submit" : "Submit",
    "Cancel" : "Bekor qilish",
    "Close" : "Yopish"
},
"nplurals=1; plural=0;");
