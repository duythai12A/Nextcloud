OC.L10N.register(
    "end_to_end_encryption",
    {
    "Internal error" : "Error interno",
    "Limit to groups" : "Limitar a grupos",
    "Save" : "Guardar",
    "Submit" : "Enviar",
    "Cancel" : "Cancel",
    "Close" : "Cerrar",
    "Select or drop files" : "Seleccione o suelte los archivos"
},
"nplurals=3; plural=n == 1 ? 0 : n != 0 && n % 1000000 == 0 ? 1 : 2;");
