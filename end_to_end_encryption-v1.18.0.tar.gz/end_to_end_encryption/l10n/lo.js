OC.L10N.register(
    "end_to_end_encryption",
    {
    "Save" : "ບັນທຶກ",
    "Cancel" : "ຍົກເລີກ",
    "End-to-end encryption" : "ສິ້ນສູດການເຂົ້າລະຫັດ ",
    "Close" : "ປິດ"
},
"nplurals=1; plural=0;");
