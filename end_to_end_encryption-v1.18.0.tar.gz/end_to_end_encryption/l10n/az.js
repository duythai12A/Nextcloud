OC.L10N.register(
    "end_to_end_encryption",
    {
    "Limit to groups" : "Qruplara limitlə",
    "Limit app usage to groups" : "Tətbiqin istifadəsini qruplar üçün limitlə",
    "Save" : "Saxla",
    "Cancel" : "Cancel",
    "Close" : "Bağla"
},
"nplurals=2; plural=(n != 1);");
