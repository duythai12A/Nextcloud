OC.L10N.register(
    "end_to_end_encryption",
    {
    "Internal error" : "Внатрешна грешка",
    "Limit to groups" : "Ограничување на групи",
    "Limit app usage to groups" : "Ограничување за користење на апликации во групи",
    "Save" : "Зачувај",
    "Submit" : "Испрати",
    "Cancel" : "Откажи",
    "Close" : "Затвори",
    "Select or drop files" : "Изберете или испуштете датотеки"
},
"nplurals=2; plural=(n % 10 == 1 && n % 100 != 11) ? 0 : 1;");
