OC.L10N.register(
    "end_to_end_encryption",
    {
    "Internal error" : "Error i brendshëm",
    "You are not allowed to delete this private key" : "Nuk je i lejuar të fshish këtë çelës privat",
    "You are not allowed to remove the lock" : "Nuk je i lejuar të fshish kyçjen",
    "File not locked" : "Skedari nuk është i kyçur",
    "Limit to groups" : "Kufizo grupet",
    "Save" : "Ruaj",
    "Submit" : "Dërgo",
    "Cancel" : "Anuloje",
    "End-to-end encryption" : "Enkriptim end-to-end ",
    "Close" : "Mbylleni",
    "Select or drop files" : "Përzgjidh ose hiq skedarët"
},
"nplurals=2; plural=(n != 1);");
