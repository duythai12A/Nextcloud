OC.L10N.register(
    "end_to_end_encryption",
    {
    "Internal error" : "Internal error",
    "Limit to groups" : "Limit to groups",
    "Limit app usage to groups" : "Limit app usage to groups",
    "Save" : "Save",
    "Submit" : "Submit",
    "I understand the risks" : "I understand the risks",
    "Cancel" : "Cancel",
    "Close" : "Close",
    "Select or drop files" : "Select or drop files"
},
"nplurals=2; plural=(n!=1);");
