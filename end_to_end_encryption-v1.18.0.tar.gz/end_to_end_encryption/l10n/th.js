OC.L10N.register(
    "end_to_end_encryption",
    {
    "Internal error" : "ข้อผิดพลาดภายใน",
    "Limit app usage to groups" : "จำกัดการใช้แอปสำหรับกลุ่ม",
    "Save" : "บันทึก",
    "Submit" : "ส่ง",
    "Cancel" : "ยกเลิก",
    "Close" : "ปิด"
},
"nplurals=1; plural=0;");
