OC.L10N.register(
    "end_to_end_encryption",
    {
    "Internal error" : "අභ්‍යන්තර දෝෂයකි",
    "Save" : "සුරකින්න",
    "Cancel" : "අවලංගු",
    "Close" : "වසන්න"
},
"nplurals=2; plural=(n != 1);");
