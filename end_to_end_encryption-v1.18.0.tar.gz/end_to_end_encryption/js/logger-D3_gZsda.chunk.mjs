import{b as e,a as t}from"./_plugin-vue2_normalizer-Cc5ATMXS.chunk.mjs";const o=n=>n===null?t().setApp("end_to_end_encryption").build():t().setApp("end_to_end_encryption").setUid(n.uid).build(),p=o(e());export{p as l};
//# sourceMappingURL=logger-D3_gZsda.chunk.mjs.map
