<!--
 ~ SPDX-FileCopyrightText: 2024 Nextcloud GmbH and Nextcloud contributors
 ~ SPDX-License-Identifier: AGPL-3.0-or-later
-->
# Authors

- Abo Khalid <53077134+myomv100@users.noreply.github.com>
- Allan Nordhøy <epost@anotheragency.no>
- Andy Scherzinger <info@andy-scherzinger.de>
- Arthur Schiwon <blizzz@arthur-schiwon.de>
- Benjamin Gaussorgues <benjamin.gaussorgues@nextcloud.com>
- Björn Schießle <bjoern@schiessle.org>
- Carl Schwan <carl@carlschwan.eu>
- Christoph Wurst <ChristophWurst@users.noreply.github.com>
- Côme Chilliet <come.chilliet@nextcloud.com>
- Daniel Kesselberg <mail@danielkesselberg.de>
- Ferdinand Thiessen <opensource@fthiessen.de>
- Florian Voit <dev@rootsh3ll.de>
- Georg Ehrke <developer@georgehrke.com>
- Joas Schilling <coding@schilljs.com>
- John Molakvoæ <skjnldsv@protonmail.com>
- Jos Poortvliet <jospoortvliet@gmail.com>
- Josh Richards <josh.t.richards@gmail.com>
- Julius Härtl <jus@bitgrid.net>
- Louis Chemineau <louis@chmn.me>
- Lukas Reschke <lukas@statuscode.ch>
- Marco Baggio <70693636+mawumag@users.noreply.github.com>
- Markus <iMarkus@users.noreply.github.com>
- Matthieu Gallien <matthieu_gallien@yahoo.fr>
- Maxence Lange <maxence@artificial-owl.com>
- Morris Jobke <hey@morrisjobke.de>
- Mostafa Ahangarha <ahangarha@riseup.net>
- Pytal <24800714+Pytal@users.noreply.github.com>
- rakekniven <2069590+rakekniven@users.noreply.github.com>
- Roeland Jago Douma <roeland@famdouma.nl>
- skjnldsv <skjnldsv@protonmail.com>
- Tobias Kaminsky <tobias@kaminsky.me>
- Valdnet <47037905+Valdnet@users.noreply.github.com>
- Vincent Petry <vincent@nextcloud.com>
- Walt <konto+zd4rv-gh@LuftHans.com>
