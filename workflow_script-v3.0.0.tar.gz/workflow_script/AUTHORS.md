<!--
  - SPDX-FileCopyrightText: 2024 Nextcloud GmbH and Nextcloud contributors
  - SPDX-License-Identifier: AGPL-3.0-or-later
-->
# Authors

- Alexandre Franke <alexandre.franke@gmail.com>
- Arthur Schiwon <blizzz@arthur-schiwon.de>
- Côme Chilliet <come.chilliet@nextcloud.com>
- Daniel Kesselberg <mail@danielkesselberg.de>
- Joas Schilling <coding@schilljs.com>
- John Molakvoæ <skjnldsv@protonmail.com>
- Jos Poortvliet <jospoortvliet@gmail.com>
- Julius Härtl <jus@bitgrid.net>
- Kilian Pfeiffer <k1l1@users.noreply.github.com>
- Michael Hartmann <94720889+cchartmann@users.noreply.github.com>
- Morris Jobke <hey@morrisjobke.de>
- Robin Windey <ro.windey@gmail.com>
- Vitor Mattos <vitor@php.rio>
